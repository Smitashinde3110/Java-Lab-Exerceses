package LabAssignments;

public class premetivedatatype {
	int a;
	double b;
	String c;
	float  d;
	long e;
	byte f;
	public premetivedatatype()
	{
		
	}
	void show()
	{
		System.out.println("int value:"+a+", double value:"+b+", char value:"+c+",float value:"+d+",long value:"+e+",byte value"+f);
	}

}
