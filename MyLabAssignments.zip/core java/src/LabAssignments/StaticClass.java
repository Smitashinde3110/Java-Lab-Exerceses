package LabAssignments;

public class StaticClass {
	

	static int roll_No1=1;
	static String name="smita";
	static String college_name="Sangola College Sangola";
	
	String blood_group;
	String village;



	
	public static  void show()
	
	
		{
	
		System.out.println("roll no is:"+roll_No1);
	System.out.println("name  is:"+name);

	System.out.println("college name:"+college_name);
	}
	
	void get(String blood_group,String village)
	{
		show();
		
		this.blood_group=blood_group;
		this.village=village;
		
	
		System.out.println("blood group is:"+blood_group);
		System.out.println("village is:"+village);
	}
	
	public static void main(String args[])
	{
		 StaticClass object=new  StaticClass();
		 object.show();
		 object.get("o+","AUndhi");
		
	}

}
