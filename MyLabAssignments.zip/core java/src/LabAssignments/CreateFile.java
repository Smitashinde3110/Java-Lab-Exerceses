package LabAssignments;

import java.io.File;

public class CreateFile
{

	public static void main(String[] args) 
	{
	    File f1= new File("E:\\newfile2.txt");
	    System.out.println("name of file:"+f1.getName());
	    System.out.println("path of file:"+f1.getPath());
	    System.out.println("absoute path  of file:"+f1.getAbsolutePath());
	    System.out.println("check exixt or not file:"+f1.exists() != null?"file exist":"file not exixt");
	    System.out.println("check file is ordinary or not:"+f1.isDirectory() != null? " file is directory":"file is not directry");
	    System.out.println("name of file:"+f1.isFile() != null? " file is ordinary":"file is not ordinary");
	    				
	}
}
