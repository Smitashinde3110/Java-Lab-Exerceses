package LabAssignments;

import java.io.IOException;

public class OpenApplication {

	public static void main(String[] args) {
		try {
			String Command= "C:\\Program Files (x86)\\Internet Explorer\\SIGNUP";
			 Runtime run  = Runtime.getRuntime();
	            Process proc = run.exec(Command);
	        }
		 catch (IOException e)
        {
            e.printStackTrace();
        }
		}
			  

}
