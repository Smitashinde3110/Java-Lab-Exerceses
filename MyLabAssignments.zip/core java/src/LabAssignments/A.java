package LabAssignments;
 class reuse {
	
public static void main(String args[])
{
	A obj=new A(1, "smita");
	obj.display();
	b obj1=new b(2,"yogesh", '0');
	obj1.get();
	
}
}



 class A{
	 int n;
	 String str;
	

	 A(int n, String str) {
		this.n = n;
		this.str = str;
	}
	 void display()
	{
		System.out.println("given number is:"+n);
		System.out.println("given name is:"+str);
	}
	
	}
 class b extends A{
	public char c;

	 b(int n, String str,char c) 
	{
		super(n, str);
		this.c=c;
		
		
	}
	 void get()
	{
		a:display();
		System.out.println("blood group is:"+c);
	}
}



	
	


	


