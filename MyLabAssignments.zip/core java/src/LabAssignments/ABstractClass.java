package LabAssignments;

public class ABstractClass {

	public static void main(String[] args) {
		Collegee object=new  Collegee();
		college_2 object_2=new  college_2();
		
		object.sports();
		object_2.sports();
		object.infotech();
		object_2.infotech();

	}

}
abstract class University{

	void infotech()
	{
		System.out.println("IT");
	}
	abstract void sports();
}
class Collegee extends University{

	@Override
	void sports() {
	System.out.println("collegge override");
		
	}

	
		
} class college_2 extends University{

	@Override
	void sports() {
		System.out.println("collegge2 override");
		
	}

	
}



