package LabAssignments;

public class Lab5Q3 {

	public static void main(String[] args) {
		Aa obj=new Aa();
		obj.get();
		B obj1=new B();
		obj1.show();
		C obj2=new C();
		obj2.display();
		D obj3=new D();
		obj3.lastClass();
		
		
		
		

	}

}
 class Aa
 {
	public Aa() 
	{
		
	}

	void get()
	{
		System.out.println("i am the main class");
		
	}

}
	
class B extends Aa{
	
	
	void show()
	{
				Aa:get();
				System.out.println("I am inherited from A Class");
			
				
		
	}


	
}
class C extends Aa
{


	void display()
	{
		Aa:get();
		
		System.out.println("I am third class inherited from A class");
		
		
	}
}
class D extends C{
	void lastClass()
	{
		C:display();
		System.out.println("I am last class inherited from c class");
	}
}
