package LabAssignments;

public class Lab6Q2 {
	public static void main()
	{
		
	}
}
class MultipleInheritace{
	String Universityname;
	 void get(String Univarsityname)
	 {
		this.Universityname=Universityname; 
		System.out.println("my name is:"+Universityname);
	 }
	
}
class Me extends MultipleInheritace{
	String Clgname;
	void set(String Clgname)
	{
		this.Clgname=Clgname;
		System.out.println("collge name is:"+Clgname);
	}
}
class You extends MultipleInheritace{
	String Clgname;

	void set(String Clgname)
	{
		this.Clgname=Clgname;
		System.out.println("collge name is:"+Clgname);
	}
	
	
}
class She extends Me, She{
	
}
