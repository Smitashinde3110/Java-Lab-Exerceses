package LabAssignments;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class Filem {

	public static void main(String[] args) throws IOException {
		String s;
		int p;
		InputStreamReader ISR=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(ISR);
		System.out.println("what is the model");
		s=br.readLine();
		System.out.println("what is the model of phone");
		p=Integer.parseInt(br.readLine());
		System.out.println("your own"+s);
		System.out.println("your price"+p);
	}

		
				

	

	
}
