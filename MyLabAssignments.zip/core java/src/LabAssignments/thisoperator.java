package LabAssignments;

public class thisoperator {
	 int number;

	public int thisoperator(int number) {
		this.number = number;
		return this.number;
	}


	public static void main(String[] args) {
		
	thisoperator object=new thisoperator();
	System.out.println(object.thisoperator(10));
		

	}

}
