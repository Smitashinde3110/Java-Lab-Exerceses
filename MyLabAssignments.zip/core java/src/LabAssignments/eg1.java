package LabAssignments;

public class eg1
{
public eg1()
{
System.out.println("Created");
}

public void display()
{
System.out.println("Hello");
}
}



