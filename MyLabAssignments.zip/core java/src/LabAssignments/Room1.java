package LabAssignments;

import java.util.Scanner;

class Room
{


	public static void main(String[] args) {
//		Scanner sc=new Scanner(System.in);
//		System.out.println("enter the room no");
//		int RoomNo=sc.nextInt();
//		System.out.println("enter the room type");
//		String RoomType=sc.nextLine();
//		System.out.println("enter the room area");
//		String RoomArea=sc.nextLine();
//		System.out.println("enter the Ac machine no");
//		int ACmachine=sc.nextInt();
		
		Room1 object=new Room1(1, "AC", "rural", 567);
		object.SetDisplay();
		//System.out.println("enter the room member");
		//String RoomMember=sc.nextLine();
		Room2 obj=  new Room2(6, "fan", "Arban", 78,"smita");
		obj.getDisplay();
	}
		

	}
public class Room1 {
	int RoomNo;
	String RoomType;
	String RoomArea;
	int ACmachine;
	

	public Room1(int roomNo, String roomType, String roomArea, int aCmachine) {
		
		this.RoomNo = roomNo;
		this.RoomType = roomType;
		this.RoomArea = roomArea;
		this.ACmachine = aCmachine;
	}
	
	
	void SetDisplay()
	{
		System.out.println("Room No is:"+RoomNo);
		System.out.println("Room type is:"+RoomType);
		System.out.println("Room Area is:"+RoomArea);
		System.out.println("Ac machine is:"+ACmachine);
	}
}
	class Room2 extends Room1
	{
	String RoomMember;
	int roomId;
	

		public Room2(int roomNo, String roomType, String roomArea, int aCmachine,String RoomMember)
		{
			super(roomNo, roomType, roomArea, aCmachine);
			this.RoomMember=RoomMember;
			
			
			
		}
		@SuppressWarnings("unused")
		void getDisplay()
		{
			super.SetDisplay();
			System.out.println("Room member is:"+RoomMember);
			
		}
	}
		

