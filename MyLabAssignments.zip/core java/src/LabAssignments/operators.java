package LabAssignments;

import java.util.Scanner;

public class operators {
void show(int a,int b)
	{
		int c;
		c=a+b;
		System.out.println(c);
		int d;
		d=a-b;
		System.out.println(d);
		int e;
		e=a*b;
		System.out.println(e);
		int f;
		f=a/b;
		System.out.println(f);
		System.out.println("=======================");
				
			}
void get(int a,int b)
{
	System.out.println("a==b:" +(a==b));
	System.out.println("a!=b:" +(a!=b));
	System.out.println("a>b:" +(a>b));
	System.out.println("a<b:" +(a<b));
	System.out.println("a>=b:" +(a>=b));
	System.out.println("a<=b:" +(a<=b));
	System.out.println("=======================");
	
}
void bitwise(int a,int b)
{
	int c;
	c=a&b;
	System.out.println("a&b:" +c);
	c=a|b;
	System.out.println("a|b:" +c);
	c=a^b;
	System.out.println("a^b:" +c);
	c=~a;
	System.out.println("~a:" +c);
	c=a<<b;
	System.out.println("a<<b:" +c);
	c=a>>b;
	System.out.println("a>>b:" +c);
	System.out.println("=======================");		
}
void conditional(int a,int b)
{
	b=(a==1)?30:40;
	System.out.println("value of b:"+b);
}
void Assignment()
{
	
}

	public static void main(String[] args) {
	int a;
	int b;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your first number");
		a=sc.nextInt();
		System.out.println("enter your second number");

			b=sc.nextInt();
			 operators object=new  operators();
			 object.show(a,b);
			 object.get(a,b);
			 object.bitwise(a, b);
			 object.conditional(a, b);
	}

}
