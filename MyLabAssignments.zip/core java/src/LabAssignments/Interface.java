package LabAssignments;

public class Interface {

	public static void main(String[] args) {
		Tyre object_1=new Tyre();
		object_1.move();
		System.out.println(object_1.ismovable());
		System.out.println(object_1.isrollable());


	}

}
interface movable{  
	int speed=50;
	void move();
	boolean ismovable();
}
interface  rollable{
	
	boolean isrollable();
}
class Tyre implements movable, rollable{

	@Override
	public boolean isrollable() {

		return false;
	}

	@Override
	public void move() {
	System.out.println("speed is:"+speed);	
		
	}

	@Override
	public boolean ismovable() {

		return false;
	}
	
}

