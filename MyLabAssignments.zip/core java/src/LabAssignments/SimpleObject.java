package LabAssignments;

import java.util.Scanner;

public class SimpleObject
{

	public SimpleObject(String Str) {
	
		System.out.println(Str);
		
	}


	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter ANY STRING");
		String str=sc.next();
		
		SimpleObject object=new SimpleObject(str);
		

	}

}
