package LabAssignments;

public class Lab13Q1 {

	public static void main(String[] args) 
	{
		InnerThread innerthread=new InnerThread();
		innerthread.run();
		
	}

}
class InnerThread implements Runnable
{
	Thread t;
	InnerThread()
	{
	t = new Thread ( this, "Test thread");
	System.out.println (" Child thread :" + t);
	t.start();
	}
	public void run()
	{
	try {
		for (int i= 5; i>0;i--)
	{
	System.out.println ("Main thread :" + i);
	Thread.sleep (500);
	}
	} catch (InterruptedException e) { }
	System.out.println ( "Main thread exiting �");
	}
	
}


