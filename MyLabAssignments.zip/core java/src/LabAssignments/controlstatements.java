package LabAssignments;

import java.util.Scanner;

public class controlstatements {
	void IfStatement(int a,int b)
	{
	if(a>b)	
	{
		System.out.println("a is greater");
		System.out.println("===================");
	}
	}
	void IfElseStatement(int a,int b)
	{
	if(a>b)	
	{
		System.out.println("a is greater");
	}
	else
	{
		System.out.println("b is greater");
	}
	System.out.println("===================");
	}
	void IfElseIfStatement(int a,int b,int c)
	{
	if(a>b)	
	{
		System.out.println("a is greater");
	}
	else if(a<c)
	{
		System.out.println("c is greater");
	}
	else
	{
		System.out.println("b is greater");
	}
	System.out.println("===================");
	}
	void Switch(int a,int b,int c,char operator)
	{
		switch(operator)
		{
		case '+':
			c=a+b;
			System.out.println("additon:"+c);
			break;
		case '-':
			c=a-b;
			System.out.println("substracton:"+c);
			break;
		case '*':
			c=a*b;
			System.out.println("multiplication:"+c);
			break;
		case '%':
			c=a+b;
			System.out.println("division:"+c);
			break;
		case '/':
			c=a+b;
			System.out.println("modulus:"+c);	
		}
		System.out.println("===================");
	}

	void For(int n)
	{
		int sum=0;
		int i;
		for(i=0;i<5;i++)
		{
			
			sum=sum+i;
		}
		System.out.println("sum of all number is"+sum);
		System.out.println("===================");
	}
	void While(int n)
	{
		int sum=0;
		int i=0;
		while(n>i)
		{
			
			sum=sum+i;
			i++;
		}
		
		System.out.println("sum of all number is"+sum);
		System.out.println("===================");
	}


	public static void main(String[] args) {
		int a,b;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your first number");
		a=sc.nextInt();
		System.out.println("enter your second number");
		b=sc.nextInt();
		controlstatements object=new controlstatements();
		object.IfStatement(a,b);
		object.IfElseStatement(a,b);
		int c;
		System.out.println("enter your third number");
		c=sc.nextInt();
		object.IfElseIfStatement(a,b,c);
	char operator ;
		System.out.println("enter any operator");
		operator=sc.next().charAt(0);
		object.Switch(a,b,c,operator);
		int n;
		System.out.println("enter any number");
		n=sc.nextInt();
		object.For(n);
		object.While(n);
		
		
		

	}

}
