package LabAssignments;

public class Point {
	private int x,y;
	public Point()
	{
		
	}

	public Point(int x, int y) {
		super();
		this.x = x;
		this.y = y;
		System.out.println("value of x:"+x);
		System.out.println("value of y:"+y);
	}
	public void SetX(int x)
	{
		this.x=x;
		System.out.println("value of x:"+x);
	}
	public void SetY(int y)
	{
		this.y=y;
		System.out.println("value of y:"+y);
	}
	public void SetXY(int x,int y)
	{
		this.x=x;
		this.y=y;
		System.out.println("value of x:"+x);
		System.out.println("value of y:"+y);
	}

	public static void main(String[] args) {
		Point obj=new Point(2,4);
		obj.SetX(6);
		obj.SetY(8);
		obj.SetXY(10, 12);
	

	}

}
