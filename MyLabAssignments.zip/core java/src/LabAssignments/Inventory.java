package LabAssignments;

public class Inventory {
	static int qoh = 500;
	static int req = 0;
	private static int p;

	static public synchronized void request( int order)
	{
		try {
	if (order 0:p--)
	{
	System.out.println ("======================");
	System.out.println (" main thread :" + p);
	System.out.println ("======================");
	Thread.sleep (1000);
	}
	} 
		catch (InterruptedException e) { }

	System.out.println (" exiting main thread . ..");
	}
	}
		
		class OurThread extends Thread
		{
		OurThread()
		{
		super ("test thread");
		System.out.println("child thread :" + this);
		start();
		}
		public void run()
		{
		for(int i=5; i > 0; i--)
		{
		try
		{
		sleep(100);
		} catch(InterruptedException e ) { }

		Inventory.request((int)(Math.random()*100));
		}
	

	}

}
