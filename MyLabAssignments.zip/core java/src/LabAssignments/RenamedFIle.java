package LabAssignments;

import java.io.File;

public class RenamedFIle {

	

	public static void main(String[] args) {
		File oldfile =new File("E:\\newfile.txt");
		File newfile =new File("E:\\yogesh.txt");
		
	        boolean flag = oldfile.renameTo(newfile);
		if(flag)
		{
		   System.out.println("File renamed successfully");
		}
		else 
		{
		   System.out.println("Rename operation failed");
	 }

	if(newfile.delete())
	{
	    System.out.println(newfile.getName() + " is deleted!");
     }
	else
     {
	    System.out.println("Delete failed: File didn't delete");
	  }
	}
}
