package LabAssignments;

public class Lab6Q4 {

	public static void main(String[] args) {
		Outer outer = new Outer();
		outer.display();
		outer.test();
		

	}

}
	class Outer{
		String so ="i am outer class";
		void display()
		{
		System.out.println(so);
		}
		void test(){
		Inner inner = new Inner();
		inner.display();
		}
		//this is an inner class
		class Inner{
		String si ="i am inner class";
		void display(){
		System.out.println(si);
		}
		}
		}

