package LabAssignments;

public class Circle4 {
	
public 	double r;
	public void area()
	{

	System.out.println("Area of the circle = " + (3.14 * r * r));
	}
	}
	class Square6
	{
	double s;
	void area()
	{
	System.out.println("Area of the Square = " + (s * s));
	}
	}
	class Rectangle
	{
	double l,b;
	void area()
	{
	System.out.println("Area of the circle = " + (l * b));
	}
	}

