package LabAssignments;

import java.io.File;

public class Directory {

	public static void main(String[] args)
	{
		String Directory="E:\\languages\\java\\program\\error\\corerection\\compile\\run\\console\\output";
		File f=new File(Directory);
		boolean result=f.mkdirs();
		
		if(result)
		{
			System.out.println("directory is ready");
		}
		else
		{
			System.out.println("directory is not ready");
		}
		

	}

}
