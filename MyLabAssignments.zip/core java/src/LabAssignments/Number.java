package LabAssignments;

public class Number {
	private double number;
	

	public Number(double number) {
		super();
		this.number = number;
	}
	boolean isZero()
	{
		if(number==0)
		{
			return true;
		}
		else
		{
		return false;
	
	}
	}
	boolean isPositive()
	{
	if(number>0)
	{
		return true;
		
	}
	else 
	{
		return false;
	}
	
	}
	boolean isOdd()
	{
		if(number%2!=0)
		{
			return true;
		}
		else 
		{
			 return false;
		}
	}
	boolean isPrime()
	{
		int  f=0;
		   int  i=2;
		    while(i <= number/2)
		    {
		        if(number%i == 0)
		        {
		            f=1;
		            break;
		        }
		        i++;
		    }
		    if(f==0)
		    {
		    	return false;
		    }
		    else
		    {
		    	return true;
		    }
	}
	boolean isArmstrong()
	{
		double temp;
		double r;
		double sum=0;
		temp=number;    
		while(number>0)    
		{    
		r=number%10;    
		sum=sum+(r*r*r);    
		number=number/10;    
		}    
		if(temp==sum)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	double getFactorial()
	{
		double fact = 1;
		for(int i=1;i<=number;i++){    
		      fact=fact*i;    
		  }   
		return fact;
		
	}
	
	void  getsqr()
	{
		double k= number*number;
		
System.out.println(k);
	}
	
	


	 	public static void main(String[] args) {
	 		Number obj = new Number(4);
	 		System.out.println(obj.isZero());
	 		System.out.println(obj.isPositive());
	 		System.out.println(obj.isOdd());
	 		System.out.println(obj.isPrime());
	 		System.out.println(obj.isArmstrong());
	 		System.out.println(obj.getFactorial());
	 	obj.getsqr();
	 		
	 		
		

	}

}

