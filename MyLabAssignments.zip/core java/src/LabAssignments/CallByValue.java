package LabAssignments;

public class CallByValue extends thisoperator {
	int number=20;
	int CallByVAlue(int data)
	{
		 data=data+number;
		 return data;
	}
	void CallByRefernce(int a)
	{
		
	}

	public static void main(String[] args) {
		
		CallByValue object=new CallByValue();
		System.out.println("value before pass "+object.number);
		
		object.CallByVAlue(10);
		object.CallByRefernce(15);		
		System.out.println("value after pass "+object.CallByVAlue(10));
				

	}

}
