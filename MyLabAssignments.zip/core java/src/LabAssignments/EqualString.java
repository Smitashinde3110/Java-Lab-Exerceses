package LabAssignments;

import java.util.Scanner;

public class EqualString {
	public static void main(String[] args) 
	{
	String s1,s2;
	Scanner sc=new Scanner(System.in);
	System.out.println("enter your first string");
	s1=sc.nextLine();
	System.out.println("enter your second string");

		s2=sc.nextLine();
		if(s1.equals(s2)==true)
		{
			System.out.println("strings are equal");
		}
		else
		{
			System.out.println("strings  not are equal");
		}
	}
	}
 