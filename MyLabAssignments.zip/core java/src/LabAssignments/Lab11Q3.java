package LabAssignments;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringReader;
import java.util.Scanner;

public class Lab11Q3 {

	public static void main(String[] args)
	{
		File fileName = new File("E:\\smita.txt");
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the string");
		
		
		  String str = sc.nextLine();
		 
	  
	        // attach a file to FileWriter 
	        FileWriter fw = null;
			try {
				fw = new FileWriter("E:\\\\smita.txt");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  
	        // read character wise from string and write 
	        // into FileWriter 
	        for (int i = 0; i < str.length(); i++)
				try {
					fw.write(str.charAt(i));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	  
	        System.out.println("Writing successful");
	        //close the file 
	        try {
				fw.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
