package LabAssignments;
class Arithmetic implements TEST90{

	@Override
	public void square() {
		System.out.println("i am square");
		System.out.println("area of square:"+area);
		
	}
	
}

interface TEST90{
	double area = 20;
	void square();
}
