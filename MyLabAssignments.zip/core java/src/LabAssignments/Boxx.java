package LabAssignments;

public class Boxx {

	public static void main(String[] args) {
		box b=new box();
		System.out.println(b.Area(10, 5, 2));
		System.out.println(b.Volume(10, 5, 2));
		box2 c=new box2();
		System.out.println(b.Area(20, 7, 1));
		System.out.println(b.Volume(20, 7, 1));

	}

}
class box{
	int length;
	int breadth;
	int height;
	public box() {
		
	}
	double Area (int length,int breadth,int height)
	{
		double SA;
		SA=2*(length*breadth)+2*(length*height)+2*(height*breadth);
		return SA;
		
	}
	double Volume(int length,int breadth,int height)
	{
		return length*breadth*height;
	}
}
class box2 extends box{
	int length,breadth,height;

	public box2() {
	
		
	}
	double Area (int length,int breadth,int height)
	{
		double SA;
		SA=2*(length*breadth)+2*(length*height)+2*(height*breadth);
		return SA;
		
	}
	double Volume(int length,int breadth,int height)
	{
		return length*breadth*height;
	}
	
	}
	

