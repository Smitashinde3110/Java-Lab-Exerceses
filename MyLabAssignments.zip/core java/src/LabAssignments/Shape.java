package LabAssignments;

public class Shape {

	public static void main(String[] args) {
		Circle object=new Circle();
		object.circle(2,3.14);
		System.out.println("Area of circle:"+object.Area());
		Triangle object1=new Triangle();
		object1.Tr(4,6);
		System.out.println("Area of Triangle:"+object1.Area());
		Square object2=new Square();
		object2.square(3);
		System.out.println("Area of Square:"+object2.Area());



	}

}
class Shapes
{
	double area;
}
class Circle extends Shapes{
	int Radius;
	double pay;
	//double Area;
	void circle(int r,double p)
	{
		this.Radius=r;
		this.pay=p;
	}
	double Area()
	{
		return Radius*Radius*pay;
	}
	
}
class Triangle extends Shapes{
	double height;
	double base;
	//double Area;
	void Tr(double h,double b)
	{
		this.height=h;
		this.base=b;
	}
	double Area()
	{
		return 1/2*(height*base);
	}
	
}
class Square extends Shapes{
	double A;
	//double Area;
	void square(double a)
	{
		this.A=a;
		
	}
	double Area()
	{
		return A*A;
	}
	
}


