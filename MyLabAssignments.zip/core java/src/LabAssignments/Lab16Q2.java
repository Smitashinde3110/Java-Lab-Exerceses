package LabAssignments;

public class Lab16Q2 {

	public static void main(String[] args) {
		YouThread thread1 = new YouThread ("thread1:");
		YouThread thread2 = new YouThread ("thread2:");
		thread1.start ( );
		thread2.start ( );
		boolean thread1IsAlive = true;
		boolean thread2IsAlive = true;
		do
		{
		if (thread1IsAlive && !thread1.isAlive ( ) )
		{
		thread1IsAlive = false;
		System.out.println ("Thread 1 is dead.");
		}
		if (thread2IsAlive && !thread2.isAlive ( ))
		{
		thread2IsAlive = false;
		System.out.println ("Thread 2 is dead.");
		}
		}while (thread1IsAlive || thread2IsAlive);

	}

}
class YouThread extends Thread
{
static String message [ ] = {"Java", "is", "hot", "aromatic,","and", "invigorating." };
public YouThread (String id)
{
super (id);
}
public void run ( )
{
SynchronizedOutput.displayList (getName(),message);
}

void randomwait()
{
try
{
sleep ( (long ) (3000*Math.random ( )) );
}

catch (InterruptedException x )
{
System.out.println ("Interrupted!");
}
}
}
class SynchronizedOutput
{
public static synchronized void displayList(String name,
String list [ ])
{
for (int i=0;i<list.length; ++i)
{
YouThread t = (YouThread) Thread.currentThread ( );
t.randomwait ();
System.out.println (name + list [i]);
}
}
}
