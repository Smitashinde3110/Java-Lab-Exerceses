package LabAssignments;

import java.util.Scanner;

public class MultupleCatchBlock1 {

	public static void main(String[] args) {
		int a[]=new int[5];   
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the elements of the array: ");  
        for(int i=0; i<5; i++)  
        {    
        a[i]=sc.nextInt();  
        } 
		 try{    
             
             a[2]=30/0;    
		 }
        
		 
		 
            catch(ArithmeticException e)  
               {  
                System.out.println("Arithmetic Exception occurs");  
               }    
            catch(ArrayIndexOutOfBoundsException e)  
               {  
                System.out.println("ArrayIndexOutOfBounds Exception occurs");  
               }    
            catch(Exception e)  
               {  
                System.out.println("Parent Exception occurs");  
               }             
            System.out.println("rest of the code");    

	}

}
