package LabAssignments;

public class MethodOverRiding {
	

	public static void main(String[] args) {
		 Abc obj=new Abc();	
		 obj.get(1, "smita");
		 xyz obj1=new xyz();
		 obj1.get(2, "rutu");
		 
	

	}

}
 class  Abc
{
	void get(int a,String b)
	{
		System.out.println("values of a is:"+a);
		System.out.println("values of b is:"+b);
	}
	
}
 class xyz extends Abc{

	@Override
	void get(int a, String b) 
	{
		super.get(a, b);
	}
 }

	