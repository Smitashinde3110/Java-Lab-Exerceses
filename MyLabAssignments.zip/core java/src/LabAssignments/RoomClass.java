package LabAssignments;

import java.util.Scanner;

public class RoomClass {
	int RoomNo;
	String RoomType;
	String RoomArea;
	int ACmachine;
	void SetData(int roomno,String roomtype,String roomarea,int acmachine)
	{
		this.RoomNo=roomno;
		this.RoomType=roomtype;
		this.RoomArea=roomarea;
		this.ACmachine=acmachine;
	}
	void SetDisplay()
	{
		System.out.println("Room No is:"+RoomNo);
		System.out.println("Room type is:"+RoomType);
		System.out.println("Room Area is:"+RoomArea);
		System.out.println("Ac machine is:"+ACmachine);
	}
	

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the room no");
		int RoomNo=sc.nextInt();
		System.out.println("enter the room type");
		String RoomType=sc.nextLine();
		System.out.println("enter the room area");
		String RoomArea=sc.nextLine();
		System.out.println("enter the Ac machine no");
		int ACmachine=sc.nextInt();
		RoomClass object=new RoomClass();
		
		object.SetData(RoomNo,RoomType,RoomArea,ACmachine);
		object.SetDisplay();
		


	}

}
