package SessionTask;

import dom.neosoft.employee;

public class firstSessionTAsk {

	public static void main(String[] args) {

		devoloper Dev[]=
			{
				
				new devoloper(101,"smita",4,4000,"java", "ecommerese"),
				new devoloper(102,"yogesh",5,12000,"php", "student"),
				new devoloper(103,"ram",5,10000,"python", "mechanical")
				};
			
		for(devoloper j:Dev)
		{
		if(j.salary>10000)
		{
		j.ShowId();
		j.ShowProfile();
		}
		}
			 
			intern arr_2[] =
				{
		new intern(101,"smita",4,4000,"java", "ecommerese",8,"oop"),
		new intern(102,"yogesh",5,12000,"php", "student",12,"poly"),
		new intern(103,"ram",5,10000,"python", "mechanical",13,"abs")
			};
		
			for(intern j:arr_2)
			{
			if(j.salary<10000)
			{
			j.ShowId();
			j.ShowProfile();
			j.ShowStatus();
			}
			}
	}

}
 class  Employee {

	 int empId;
	 String ename;
	 int deptno;
 double salary;

	 public Employee(int empId,String ename,int deptno,double salary)
	{
	this.empId= empId;
	this.ename=ename;
	this.deptno=deptno;
	this.salary=salary;
		
}
	public void ShowId()
	{
		System.out.println("emp id:"+empId);
		System.out.println("emp name:"+ename);
	System.out.println("emp dept no:"+deptno);
	System.out.println("emp salary:"+salary);

	}
}
 class  devoloper extends employee {
		 String skills;
		 String project_name;
		
		
		public devoloper(int empId, String ename, int deptno,  double salary, String skills, String project_name)
		{
			super(empId, ename, deptno,  salary);
			this.skills = skills;
			this.project_name = project_name;
		}


		public void ShowProfile()
		{
		System.out.println("devoloper skills:"+skills);
		System.out.println("devoloper project name:"+project_name);

		}
	}
  class intern extends devoloper{
		 int probabation;
		 String  certificate;
		 intern(int empId, String ename, int deptno, double salary, String skills, String project_name,
				int probabation, String certificate)
		 {
			super(empId, ename, deptno, salary, skills, project_name);
			this.probabation = probabation;
			this.certificate = certificate;
		}
		
		public void ShowStatus()
		{
			System.out.println("intern probabation:"+ probabation);
			System.out.println("intern certificate name:"+certificate);
		}
		

	}
