package SessionTask;
import java.util.Date;
import java.util.Scanner;

public class JavaProject2
{
	public  String name;
	public  String address;
  public    String contact_no;
   public   String user_name;
   public  String password;
	public int deposit;
	public int amount;
	public String account_type;
	public JavaProject2()
	{
	}
	
	public JavaProject2(String name, String address, String contact_no, String user_name, String password, int deposit,
			int amount, String account_type) {
		super();
		this.name = name;
		this.address = address;
		this.contact_no = contact_no;
		this.user_name = user_name;
		this.password = password;
		this.deposit = deposit;
		this.amount = amount;
		this.account_type = account_type;
	}
	

	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getContact_no() {
		return contact_no;
	}

	public void setContact_no(String contact_no) {
		this.contact_no = contact_no;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

	public int getDeposit() {
		return deposit;
	}

	public void setDeposit(int deposit) {
		this.deposit = deposit;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getAccount_type() {
		return account_type;
	}
	public void setAccount_type(String account_type) {
		this.account_type = account_type;
	}
	void display()
	{
	System.out.println("-----------------------------");
	System.out.println("BANK   OF  MYBANK");
	System.out.println("-----------------------------");

	System.out.println("1. Register Account");
	System.out.println("2. Login");
	System.out.println("3. Update accounts");
	System.out.println("4. Exit");
	System.out.println();
	Scanner sc=new Scanner(System.in);
	System.out.print("Enter Your Choice :");
	int choice = sc.nextInt();
	if(choice==1)
	{
	
		System.out.print("Enter name :");
		String name = sc.next();
		

		System.out.print("Enter address :");
		String address = sc.next();

		System.out.print("Enter Contact Number :");
		String contact_no = sc.next();
		

		System.out.print("Set Username :");
		String user_name = sc.next();

		System.out.print("set password :");
		String password = sc.next();
		while (!password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$@!%&*?])[A-Za-z\\d#$@!%&*?]{8,30}$")) 
		{
			System.out.println("Invalid Password");
			System.out.print("Enter Password again :");
			password = sc.next();
		}
		String password1 = password;

		

		System.out.print("Enter Initial Deposit :");
		int deposit = sc.nextInt();
		display();
	}
		if (choice == 2) 
		{

			System.out.print("Enter Username :");
			String user_name1 = sc.next();

			System.out.print("Enter password :");
			String password1 = sc.next();

//			while (password1.equals(password) || user_name.matches(user_name1)) 
//			{
//				System.out.println("Invalid Username and Password! \r\n");

//				System.out.print("Enter Username :");
//				user_name1 = sc.next();
	//
//				System.out.print("Enter password :");
//				password1 = sc.next();
			System.out.println("Login Successfully");
			show();
			
		}
	}
	void show()
	{
	Scanner sc = new Scanner(System.in);
	amount = deposit;
	System.out.println("-----------------");
	System.out.println("WELCOME");
	System.out.println("-----------------");

	System.out.println("1. Deposit");
	System.out.println("2. Transfer");
	System.out.println("3. Last 5 Transactions");
	System.out.println("4. User Information");
	System.out.println("5. Log out");

	System.out.println();
	System.out.print("Enter Your Choice : ");
	int choice1 = sc.nextInt();
	if (choice1 == 1) 
	{
		System.out.print("Enter amount : ");
		int tempAmt = sc.nextInt();
		amount= amount+tempAmt;
		System.out.println(amount);
	show();
	}
	if (choice1 == 4) 
	{
		System.out.println("Accountholder Name :" + getName());
		System.out.println("Accountholer Address :" + getAddress());
		System.out.println("Accountholder Contact :" + getContact_no());
		System.out.println("Account Type : " + getAccount_type());
		show();
	}
	if (choice1 == 3) 
	{
		System.out.println("Rs. " + deposit + " credited to your account. Balance Rs. " + deposit + " as on " + new Date().getDate());
		System.out.println("Initial Deposit - Rs " + deposit + " as on " + new Date().getDate() );
	show();
	}
	if (choice1 == 2) {
		System.out.println("Enter Payee Username :");
		String pusername = sc.next();
		System.out.println("Enter Amount : ");
		amount = sc.nextInt();
		System.out.println("Username does not exist.");
		show();
	}
	if (choice1 == 5) 
	{
		display();
	}
	}
	
	

	public static void main(String[] args)
			{
		JavaProject2 j=new JavaProject2();
		j.display();
//	j.show();
		
	
	
			}
}




