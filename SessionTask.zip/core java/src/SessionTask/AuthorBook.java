package SessionTask;

import java.util.ArrayList;


public class AuthorBook {

	public static void main(String[] args)
	{
		ArrayList<Book> book=new ArrayList<Book>();
		book.add(new Book(101,"Java",600));
		book.add(new Book(102,"C",120));
		book.add(new Book(103,"C++",81));
		book.add(new Book(104,"C#",94));
	

	}

}
class Book
{
	int book_id;
	String book_name;
	int book_price;
	private Object arrAuthor;
//char[] arrAuthor;
public Book(int book_id, String book_name, int book_price) {
	super();
	this.book_id = book_id;
	this.book_name = book_name;
	this.book_price = book_price;
	this.arrAuthor = arrAuthor;
}
public int getBook_id() {
	return book_id;
}
public void setBook_id(int book_id) {
	this.book_id = book_id;
}
public String getBook_name() {
	return book_name;
}
public void setBook_name(String book_name) {
	this.book_name = book_name;
}
public int getBook_price() {
	return book_price;
}
public void setBook_price(int book_price) {
	this.book_price = book_price;
}
public char[] getArrAuthor() {
	return (char[]) arrAuthor;
}
public void setArrAuthor(char[] arrAuthor) {
	this.arrAuthor = arrAuthor;
}

}
